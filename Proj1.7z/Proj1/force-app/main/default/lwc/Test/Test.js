
import { LightningElement, track } from 'lwc';
import getContactList from '@salesforce/apex/ContactList.getContactList';

export default class Test extends LightningElement {
    @track contacts;
    @track error;
    
    handleLoad() {
        var consoleObj = window.console;
        getContactList()
            .then(result => {
                this.contacts = result;
                consoleObj.log("result",result);
            })
            .catch(error => {
                this.error = error;
            });
            
            
            
            
    }
}