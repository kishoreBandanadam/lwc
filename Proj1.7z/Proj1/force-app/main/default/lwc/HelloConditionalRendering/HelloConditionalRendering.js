import { LightningElement, track } from 'lwc';

export default class HelloConditionalRendering extends LightningElement {

    @track details = false;

    handleChange(event) {
        this.details = event.target.checked;
    }
}