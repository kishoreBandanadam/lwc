import { LightningElement, track } from 'lwc';
import findContacts from '@salesforce/apex/ContactController.findContacts';
export default class ApexMethod extends LightningElement {
    @track searchKey = '';
    @track contacts;
    @track error;
    
    handleKeyChange(event) {
        this.searchKey = event.target.value;
    }
    
    handleSearch() {
        
        findContacts({searchKey : this.searchKey})
            .then(result => {
                this.contacts = result;
                this.error = undefined;
                // eslint-disable-next-line no-console
                this.newMethod(this.contacts);
            })
            .catch(error => {
                this.contacts = undefined;
                this.error = error;
            })
    }

    newMethod(result) {
        // eslint-disable-next-line no-console
        console.log("result001", result);
        // eslint-disable-next-line no-console
        console.log('COnsole');
    }
}