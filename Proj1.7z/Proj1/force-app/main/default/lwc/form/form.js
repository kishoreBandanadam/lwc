import { LightningElement, api, wire } from 'lwc';
import { getRecord } from 'lightning/uiRecordApi';

export default class Form extends LightningElement {

    @api recordId;
    
    @wire(getRecord, {recordId : '$recordId', fields:['Account.Name']}) record;
}